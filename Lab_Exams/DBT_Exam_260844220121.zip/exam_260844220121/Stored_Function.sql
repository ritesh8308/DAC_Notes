DROP FUNCTION IF EXISTS total_salary;

DELIMITER $$

CREATE FUNCTION total_salary(IN dept_id, OUT total_sal)
DETERMINISTIC
BEGIN
DECLARE total_sal BIGINT DEFAULT 0,

SET @total_sal = SELECT SUM(salary) FROM Tb_emp


END;
$$
DELIMITER ;