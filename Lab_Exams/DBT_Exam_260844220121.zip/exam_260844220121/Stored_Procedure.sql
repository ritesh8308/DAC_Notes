DROP PROCEDURE IF EXISTS calc_Salary;

DELIMITER $$

CREATE PROCEDURE calc_Salary(IN basic_sal, IN hra, IN da, OUT Month_salary, OUT Annual_Salary);
BEGIN

DECLARE Monthly_salary DECIMAL(9,2) DEFAULT 0.00;
DECLARE Annual_salary DECIMAL(9,2) DEFAULT 0.00;

SET Month_salary = basic_sal + hra + da;
SET Annual_Salary = Month_salary * 12;

INSERT INTO tempp(`Month_salary`, `Annual_Salary`)
VALUES(Month_salary, Annual_Salary);

END;
$$
DELIMITER ;